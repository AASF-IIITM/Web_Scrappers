import os
import time

from selenium import webdriver
from selenium.webdriver.common.action_chains import ActionChains
from selenium.webdriver.common.by import By
from selenium.webdriver.firefox.firefox_profile import FirefoxProfile
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.support.ui import WebDriverWait


class Actions(ActionChains):
    def wait(self, time_s: float):
        self._actions.append(lambda: time.sleep(time_s))
        return self


url = 'http://nhb.gov.in/OnlineClient/categorywiseallvarietyreport.aspx?enc=3ZOO8K5CzcdC' \
      '/Yq6HcdIxJ4o5jmAcGG5QGUXX3BlAP4= '

path = "/home/shubham/Downloads/geckodriver"
profile = FirefoxProfile()
# profile.set_preference("browser.download.panel.shown", False) profile.set_preference(
# "browser.helperApps.neverAsk.openFile","text/plain, application/vnd.ms-excel, text/csv,
# text/comma-separated-values, application/octet-stream,
# application/vnd.openxmlformats-officedocument.spreadsheetml.sheet") profile.set_preference(
# "browser.helperApps.neverAsk.saveToDisk", "text/plain, application/vnd.ms-excel, text/csv,
# text/comma-separated-values, application/octet-stream,
# application/vnd.openxmlformats-officedocument.spreadsheetml.sheet") profile.set_preference(
# "browser.download.folderList", 2); profile.set_preference("browser.download.dir", "/home/chinmay/Downloads/")

profile.set_preference('browser.download.folderList', 2)
profile.set_preference('browser.download.manager.showWhenStarting', False)
profile.set_preference('browser.download.dir', os.getcwd())
profile.set_preference('browser.helperApps.neverAsk.saveToDisk', 'application/vnd.ms-excel')
driver = webdriver.Firefox(executable_path=path, firefox_profile=profile)

# driver.maximize_window()
driver.get(url)
date = driver.find_element_by_id("ctl00_ContentPlaceHolder1_txtdate")
date.send_keys('10/12/2018')

category = driver.find_element_by_id("ctl00_ContentPlaceHolder1_drpCategoryName")
category.send_keys('FLOWERS')

states = driver.find_element_by_id("ctl00_ContentPlaceHolder1_btSelectAll").click()

# click = WebDriverWait(driver,20).until(EC.element_to_be_clickable((By.ID,
# "ctl00_ContentPlaceHolder1_btnSearch"))).click()

click = driver.find_element_by_xpath('//*[@id="ctl00_ContentPlaceHolder1_btnSearch"]')
ActionChains(driver).move_to_element(click).click().perform()
# Actions(driver).move_to_element(click).wait(4).click().perform()

element = WebDriverWait(driver, 50).until(
    EC.element_to_be_clickable((By.XPATH, '//*[@id="ctl00_ContentPlaceHolder1_btnExcel"]'))).click()

# sleep(30)
# element = driver.find_element_by_xpath('//*[@id="ctl00_ContentPlaceHolder1_btnExcel"]')
# element.click()


# element = WebDriverWait(driver, 40).until(EC.presence_of_element_located((By.ID,
# "ctl00_ContentPlaceHolder1_btnExcel"))) element.click()


# click = WebDriverWait(driver, 20).until(EC.invisibility_of_element_located(By.ID,
# "ctl00_ContentPlaceHolder1_btnSearch")) click.click()


# element.click()

# driver.execute_script("arguments[0].setAttribute('style', arguments[1]);", click, "color: red; border:3px solid red;")


# //*[@id="ctl00_ContentPlaceHolder1_btnExcel"]
